
PKGNAME = "Gnosis_Utils"

# this gets bumped on every release
MAJOR = 1
MINOR = 2
SUBVER = 2
EXTRA = ''

VSTRING = "%d.%d.%d%s" % (MAJOR,MINOR,SUBVER,EXTRA)
