"""Utilities and Interfaces to make XML more Pythonic

Please see the information in subpackages and submodules for
explanation of usage, design, license, and other details
"""
