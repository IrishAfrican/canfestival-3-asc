"""Transform XML Documents to Python objects

Please see the information at gnosis.xml.objectify.doc for
explanation of usage, design, license, and other details
"""

from utils import *
from _objectify import *
from _objectify import _XO_

# This call will enable namespace support in EXPAT
config_nspace_sep()
