"""Library of Python objects that conform to XML validity rules

Requires: Python 2.2+
(may use new-style classes, slots, properties, metaclasses)
"""

from _validity import *

